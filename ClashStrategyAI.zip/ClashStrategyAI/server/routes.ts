import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertStrategySchema, insertUserSchema } from "@shared/schema";
import OpenAI from "openai";
import { getPlayerByTag, formatPlayerInfo } from "./cocApi";

// Initialize OpenAI
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "demo-key"
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Clash of Clans API routes
  app.get("/api/coc/player/:tag", async (req, res) => {
    try {
      const { tag } = req.params;
      
      if (!tag) {
        return res.status(400).json({ message: "Player tag is required" });
      }
      
      const playerData = await getPlayerByTag(tag);
      const formattedData = formatPlayerInfo(playerData);
      
      res.status(200).json(formattedData);
    } catch (error: any) {
      console.error("Error fetching player data:", error);
      res.status(error.statusCode || 500).json({ 
        message: error.message || "Failed to fetch player data" 
      });
    }
  });
  // User routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const newUser = await storage.createUser(userData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  // Strategy routes
  app.get("/api/strategies", async (req, res) => {
    try {
      const strategies = await storage.getPublicStrategies();
      res.status(200).json(strategies);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/strategies", async (req, res) => {
    try {
      const strategyData = insertStrategySchema.parse(req.body);
      const newStrategy = await storage.createStrategy(strategyData);
      res.status(201).json(newStrategy);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/strategies/:id", async (req, res) => {
    try {
      const strategyId = parseInt(req.params.id);
      const strategy = await storage.getStrategy(strategyId);
      
      if (!strategy) {
        return res.status(404).json({ message: "Strategy not found" });
      }
      
      res.status(200).json(strategy);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  // Generate strategy with AI
  app.post("/api/generate-strategy", async (req, res) => {
    try {
      const { 
        userTownHallLevel, 
        opponentTownHallLevel, 
        troops, 
        spells, 
        heroes,
        generateVideo
      } = req.body;
      
      // Validate input
      if (!userTownHallLevel || !opponentTownHallLevel) {
        return res.status(400).json({ message: "Town hall levels are required" });
      }
      
      // Construct the prompt for OpenAI
      const prompt = `Generate a detailed Clash of Clans attack strategy with the following information:
      - Attacker's Town Hall level: ${userTownHallLevel}
      - Defender's Town Hall level: ${opponentTownHallLevel}
      - Available troops: ${JSON.stringify(troops)}
      - Available spells: ${JSON.stringify(spells)}
      - Hero levels: ${JSON.stringify(heroes)}
      
      Please provide:
      1. A name for this strategy
      2. A brief description
      3. Detailed step-by-step instructions
      4. Troop composition with quantities
      5. Spell usage recommendations
      6. Hero deployment advice
      7. Common mistakes to avoid
      
      Format the response as a JSON object with the following structure:
      {
        "name": "Strategy Name",
        "description": "Brief description",
        "composition": { "troops": [], "spells": [] },
        "steps": ["Step 1", "Step 2", ...],
        "heroUsage": "Advice for hero deployment",
        "commonMistakes": ["Mistake 1", "Mistake 2", ...],
        "successRate": 85 // Estimated success rate percentage
      }`;
      
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: "You are a Clash of Clans expert who provides detailed attack strategies." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" }
      });
      
      // Parse the response
      const strategyContent = JSON.parse(response.choices[0].message.content);
      
      // Return the generated strategy
      res.status(200).json({
        strategy: strategyContent,
        generatedVideo: generateVideo ? "https://example.com/video" : null // Mock video URL
      });
    } catch (error) {
      console.error("Strategy generation error:", error);
      res.status(500).json({ message: "Failed to generate strategy" });
    }
  });

  // Subscription plans routes
  app.get("/api/subscription-plans", async (req, res) => {
    try {
      const plans = await storage.getSubscriptionPlans();
      res.status(200).json(plans);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/subscribe", async (req, res) => {
    try {
      const { userId, planId } = req.body;
      
      // Get the user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get the plan
      const plan = await storage.getSubscriptionPlan(planId);
      if (!plan) {
        return res.status(404).json({ message: "Subscription plan not found" });
      }
      
      // Start trial
      const now = new Date();
      const trialEnd = new Date(now.setDate(now.getDate() + 7)); // 7-day trial
      
      // Update user subscription
      const updatedUser = await storage.updateUserSubscription(userId, {
        subscriptionPlan: plan.name,
        trialEnd: trialEnd,
        subscriptionEnd: null // Will be set after trial
      });
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
