import fetch from 'node-fetch';
import { TROOPS, SPELLS, HEROES } from '../shared/constants';

// Format the player tag to ensure it starts with '#'
export function formatPlayerTag(tag: string): string {
  let formattedTag = tag.trim();
  if (!formattedTag.startsWith('#')) {
    formattedTag = '#' + formattedTag;
  }
  return formattedTag;
}

// Get player data from the Clash of Clans API
export async function getPlayerByTag(tag: string) {
  const formattedTag = formatPlayerTag(tag);
  const encodedTag = encodeURIComponent(formattedTag);
  
  try {
    const response = await fetch(
      `https://api.clashofclans.com/v1/players/${encodedTag}`,
      {
        headers: {
          'Authorization': `Bearer ${process.env.COC_API_KEY}`,
          'Accept': 'application/json'
        }
      }
    );
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(
        errorData.message || 
        `Failed to fetch player data: ${response.status} ${response.statusText}`
      );
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching player data:', error);
    throw error;
  }
}

// Map COC API troops to our application format
export function mapCocTroops(playerData: any) {
  if (!playerData.troops) return [];
  
  // Filter for regular troops (excluding super troops, siege machines, etc for now)
  const regularTroops = playerData.troops.filter((troop: any) => {
    // Only include troops that are in our predefined list
    return TROOPS.some(t => 
      t.name.toLowerCase() === troop.name.toLowerCase() || 
      t.id.toLowerCase() === troop.id?.toLowerCase()
    );
  });
  
  return regularTroops.map((troop: any) => {
    // Find the matching troop in our predefined list
    const matchingTroop = TROOPS.find(t => 
      t.name.toLowerCase() === troop.name.toLowerCase() ||
      t.id.toLowerCase() === troop.id?.toLowerCase()
    );
    
    return {
      id: matchingTroop?.id || troop.id || troop.name.toLowerCase().replace(/\s+/g, '_'),
      name: troop.name,
      level: troop.level,
      maxLevel: troop.maxLevel,
      village: troop.village
    };
  });
}

// Map COC API spells to our application format
export function mapCocSpells(playerData: any) {
  if (!playerData.spells) return [];
  
  const spells = playerData.spells.filter((spell: any) => {
    return SPELLS.some(s => 
      s.name.toLowerCase() === spell.name.toLowerCase() ||
      s.id.toLowerCase() === spell.id?.toLowerCase()
    );
  });
  
  return spells.map((spell: any) => {
    const matchingSpell = SPELLS.find(s => 
      s.name.toLowerCase() === spell.name.toLowerCase() ||
      s.id.toLowerCase() === spell.id?.toLowerCase()
    );
    
    return {
      id: matchingSpell?.id || spell.id || spell.name.toLowerCase().replace(/\s+/g, '_'),
      name: spell.name,
      level: spell.level,
      maxLevel: spell.maxLevel,
      village: spell.village
    };
  });
}

// Map COC API heroes to our application format
export function mapCocHeroes(playerData: any) {
  if (!playerData.heroes) return [];
  
  const heroes = playerData.heroes.filter((hero: any) => {
    return HEROES.some(h => 
      h.name.toLowerCase().includes(hero.name.toLowerCase()) ||
      hero.name.toLowerCase().includes(h.name.toLowerCase())
    );
  });
  
  return heroes.map((hero: any) => {
    const matchingHero = HEROES.find(h => 
      h.name.toLowerCase().includes(hero.name.toLowerCase()) ||
      hero.name.toLowerCase().includes(h.name.toLowerCase())
    );
    
    return {
      id: matchingHero?.id || hero.id || hero.name.toLowerCase().replace(/\s+/g, '_'),
      name: hero.name,
      level: hero.level,
      maxLevel: hero.maxLevel,
      village: hero.village
    };
  });
}

// Get the town hall level from player data
export function getTownHallLevel(playerData: any) {
  return playerData.townHallLevel || null;
}

// Get player clan information
export function getPlayerClanInfo(playerData: any) {
  if (!playerData.clan) return null;
  
  return {
    tag: playerData.clan.tag,
    name: playerData.clan.name,
    level: playerData.clan.clanLevel,
    badgeUrl: playerData.clan.badgeUrls?.medium || null
  };
}

// Format the complete player info for our application
export function formatPlayerInfo(playerData: any) {
  return {
    tag: playerData.tag,
    name: playerData.name,
    townHallLevel: getTownHallLevel(playerData),
    expLevel: playerData.expLevel,
    trophies: playerData.trophies,
    bestTrophies: playerData.bestTrophies,
    warStars: playerData.warStars,
    attackWins: playerData.attackWins,
    defenseWins: playerData.defenseWins,
    clan: getPlayerClanInfo(playerData),
    troops: mapCocTroops(playerData),
    spells: mapCocSpells(playerData),
    heroes: mapCocHeroes(playerData)
  };
}