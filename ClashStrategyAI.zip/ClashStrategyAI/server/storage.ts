import { users, strategies, subscriptionPlans, type User, type InsertUser, type Strategy, type InsertStrategy, type SubscriptionPlan } from "../shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createUserFromGoogle(userData: {
    googleId: string;
    username: string;
    email: string;
    firstName?: string;
    lastName?: string;
    profileImageUrl?: string;
  }): Promise<User>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.googleId, googleId));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async createUserFromGoogle(userData: {
    googleId: string;
    username: string;
    email: string;
    firstName?: string;
    lastName?: string;
    profileImageUrl?: string;
  }): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        username: userData.username,
        email: userData.email,
        googleId: userData.googleId,
        firstName: userData.firstName || null,
        lastName: userData.lastName || null,
        profileImageUrl: userData.profileImageUrl || null,
        password: null // No password for Google-authenticated users
      })
      .returning();
    
    return user;
  }
  
  // Get public strategies
  async getPublicStrategies(): Promise<Strategy[]> {
    return db.select().from(strategies).where(eq(strategies.isPublic, true));
  }
  
  // Create a new strategy
  async createStrategy(strategyData: InsertStrategy): Promise<Strategy> {
    const [strategy] = await db
      .insert(strategies)
      .values(strategyData)
      .returning();
    return strategy;
  }
  
  // Get a strategy by ID
  async getStrategy(id: number): Promise<Strategy | undefined> {
    const [strategy] = await db.select().from(strategies).where(eq(strategies.id, id));
    return strategy;
  }
  
  // Get all subscription plans
  async getSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    return db.select().from(subscriptionPlans);
  }
  
  // Get a subscription plan by ID
  async getSubscriptionPlan(id: number): Promise<SubscriptionPlan | undefined> {
    const [plan] = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.id, id));
    return plan;
  }
  
  // Update user subscription
  async updateUserSubscription(userId: number, subscriptionData: {
    subscriptionPlan: string;
    trialEnd: Date | null;
    subscriptionEnd: Date | null;
  }): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({
        subscriptionPlan: subscriptionData.subscriptionPlan,
        trialEnd: subscriptionData.trialEnd,
        subscriptionEnd: subscriptionData.subscriptionEnd
      })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }
}

export const storage = new DatabaseStorage();
