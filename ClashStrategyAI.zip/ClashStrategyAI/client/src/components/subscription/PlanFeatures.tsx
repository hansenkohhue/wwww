import { Check, X } from "lucide-react";
import { PlanFeature } from "@/lib/types";

interface PlanFeaturesProps {
  features: PlanFeature[];
  className?: string;
}

export function PlanFeatures({ features, className = "" }: PlanFeaturesProps) {
  return (
    <ul className={`space-y-3 ${className}`}>
      {features.map((feature, index) => (
        <li key={index} className="flex items-start">
          {feature.included ? (
            <Check className="h-5 w-5 text-[#4CAF50] mr-2 mt-0.5" />
          ) : (
            <X className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
          )}
          <span 
            className={feature.included 
              ? "text-gray-600 dark:text-gray-300" 
              : "text-gray-500 dark:text-gray-400"
            }
          >
            {feature.name}
          </span>
        </li>
      ))}
    </ul>
  );
}
