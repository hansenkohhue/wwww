import { useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { FAQItem } from "@/lib/types";

interface FrequentlyAskedQuestionsProps {
  faqItems: FAQItem[];
}

export function FrequentlyAskedQuestions({ faqItems }: FrequentlyAskedQuestionsProps) {
  return (
    <div className="mt-10 bg-gray-100 dark:bg-dark-100 rounded-lg p-6">
      <h3 className="text-xl font-bold mb-4">Frequently Asked Questions</h3>
      
      <Accordion type="single" collapsible className="space-y-2">
        {faqItems.map((item, index) => (
          <AccordionItem 
            key={index} 
            value={`item-${index}`}
            className="border-b border-gray-200 dark:border-gray-700 pb-2"
          >
            <AccordionTrigger className="text-left font-medium text-gray-700 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
              {item.question}
            </AccordionTrigger>
            <AccordionContent className="text-gray-600 dark:text-gray-400 text-sm pt-2">
              {item.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
