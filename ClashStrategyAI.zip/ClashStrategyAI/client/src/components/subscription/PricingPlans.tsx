import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, X } from "lucide-react";
import { SubscriptionPlan } from "@/lib/types";
import { useSubscription } from "@/hooks/useSubscription";
import { useLocation } from "wouter";

interface PricingPlansProps {
  plans: SubscriptionPlan[];
}

export function PricingPlans({ plans }: PricingPlansProps) {
  const { subscribe, isSubscribing } = useSubscription();
  const [_, navigate] = useLocation();

  const handleSubscribe = (planId: number) => {
    // Instead of using the subscription hook, redirect to checkout
    navigate(`/checkout?plan=${planId}`);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {plans.map((plan) => (
        <div 
          key={plan.id}
          className={`
            rounded-lg p-6
            ${plan.isMostPopular 
              ? "border-2 border-[#1F8BFF] dark:border-[#FFD54F] bg-white dark:bg-dark-200 shadow-md relative" 
              : "border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-dark-100"}
          `}
        >
          {plan.isMostPopular && (
            <div className="absolute top-0 right-0 bg-[#1F8BFF] dark:bg-[#FFD54F] text-white dark:text-black text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-lg">
              MOST POPULAR
            </div>
          )}
          
          <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
          <div className="text-[#1F8BFF] dark:text-[#FFD54F] text-3xl font-bold mb-4">
            ${plan.price.toFixed(2)}
            <span className="text-gray-500 text-lg font-normal">/{plan.billingCycle}</span>
          </div>
          
          <ul className="space-y-3 mb-6">
            {plan.features.map((feature, index) => (
              <li key={index} className="flex items-start">
                {feature.included ? (
                  <Check className="h-5 w-5 text-[#4CAF50] mr-2 mt-0.5" />
                ) : (
                  <X className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
                )}
                <span className={feature.included 
                  ? "text-gray-600 dark:text-gray-300" 
                  : "text-gray-500 dark:text-gray-400"}>
                  {feature.name}
                </span>
              </li>
            ))}
          </ul>
          
          {plan.name === "Free" ? (
            <Button
              className="w-full py-2 px-4 border border-[#1F8BFF] dark:border-[#FFD54F] text-[#1F8BFF] dark:text-[#FFD54F] font-medium rounded-md hover:bg-blue-50 dark:hover:bg-opacity-10"
              variant="outline"
              disabled
            >
              Current Plan
            </Button>
          ) : (
            <>
              <Button
                className="w-full bg-[#1F8BFF] dark:bg-[#FFD54F] text-white dark:text-black font-medium rounded-md hover:bg-blue-600 dark:hover:bg-yellow-500"
                onClick={() => handleSubscribe(plan.id)}
                disabled={isSubscribing}
              >
                Start 7-Day Free Trial
              </Button>
              
              <div className="text-center mt-3 text-xs text-gray-500 dark:text-gray-400">
                Cancel anytime during trial
              </div>
            </>
          )}
        </div>
      ))}
    </div>
  );
}
