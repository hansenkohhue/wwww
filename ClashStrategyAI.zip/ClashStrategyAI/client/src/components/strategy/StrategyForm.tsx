import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { TroopSelection } from "./TroopSelection";
import { SpellSelection } from "./SpellSelection";
import { FileInput } from "@/components/ui/file-input";
import { PlayerTagInput } from "@/components/player/PlayerTagInput";
import { PlayerProfile } from "@/components/player/PlayerProfile";
import { useStrategy } from "@/hooks/useStrategy";
import { StrategyResult } from "./StrategyResult";
import { TOWN_HALL_LEVELS, TROOPS, SPELLS, HEROES } from "@/lib/constants";
import { StrategyFormData, Troop, Spell, Hero } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { RocketIcon, Loader2 } from "lucide-react";

export function StrategyForm() {
  const { toast } = useToast();
  const { 
    generateStrategy,
    isGenerating, 
    error,
    generatedStrategy,
    clearGeneratedStrategy
  } = useStrategy();
  
  const [formData, setFormData] = useState<StrategyFormData>({
    userTownHallLevel: "",
    opponentTownHallLevel: "",
    troops: TROOPS,
    spells: SPELLS,
    heroes: HEROES,
    generateVideo: true,
    includeDetailedGuide: false
  });
  
  const handleInputChange = (field: keyof StrategyFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };
  
  const handleTroopSelectionChange = (selectedTroops: Troop[]) => {
    setFormData(prev => ({ 
      ...prev, 
      troops: prev.troops.map(troop => ({
        ...troop,
        selected: selectedTroops.some(selected => selected.id === troop.id)
      }))
    }));
  };
  
  const handleSpellSelectionChange = (selectedSpells: Spell[]) => {
    setFormData(prev => ({ 
      ...prev, 
      spells: prev.spells.map(spell => ({
        ...spell,
        selected: selectedSpells.some(selected => selected.id === spell.id)
      }))
    }));
  };
  
  const handleHeroLevelChange = (heroId: string, level: number) => {
    setFormData(prev => ({
      ...prev,
      heroes: prev.heroes.map(hero => 
        hero.id === heroId ? { ...hero, level } : hero
      )
    }));
  };
  
  const handlePlayerDataLoaded = (playerData: any) => {
    // Update town hall level
    if (playerData.townHallLevel) {
      handleInputChange("userTownHallLevel", playerData.townHallLevel.toString());
    }
    
    // Update troops
    if (playerData.troops && playerData.troops.length > 0) {
      setFormData(prev => ({ 
        ...prev, 
        troops: prev.troops.map(troop => {
          const playerTroop = playerData.troops.find((t: any) => 
            t.name.toLowerCase() === troop.name.toLowerCase() ||
            t.id.toLowerCase() === troop.id.toLowerCase()
          );
          
          return playerTroop 
            ? { ...troop, selected: true, level: playerTroop.level } 
            : troop;
        })
      }));
    }
    
    // Update spells
    if (playerData.spells && playerData.spells.length > 0) {
      setFormData(prev => ({ 
        ...prev, 
        spells: prev.spells.map(spell => {
          const playerSpell = playerData.spells.find((s: any) => 
            s.name.toLowerCase() === spell.name.toLowerCase() ||
            s.id.toLowerCase() === spell.id.toLowerCase()
          );
          
          return playerSpell 
            ? { ...spell, selected: true, level: playerSpell.level } 
            : spell;
        })
      }));
    }
    
    // Update heroes
    if (playerData.heroes && playerData.heroes.length > 0) {
      setFormData(prev => ({ 
        ...prev, 
        heroes: prev.heroes.map(hero => {
          const playerHero = playerData.heroes.find((h: any) => 
            h.name.toLowerCase().includes(hero.name.toLowerCase()) ||
            hero.name.toLowerCase().includes(h.name.toLowerCase())
          );
          
          return playerHero 
            ? { ...hero, level: playerHero.level } 
            : hero;
        })
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.userTownHallLevel) {
      toast({
        title: "Missing information",
        description: "Please select your Town Hall level",
        variant: "destructive"
      });
      return;
    }
    
    if (!formData.opponentTownHallLevel) {
      toast({
        title: "Missing information",
        description: "Please select opponent's Town Hall level",
        variant: "destructive"
      });
      return;
    }
    
    const selectedTroops = formData.troops.filter(troop => troop.selected);
    if (selectedTroops.length === 0) {
      toast({
        title: "Missing information",
        description: "Please select at least one troop",
        variant: "destructive"
      });
      return;
    }
    
    // Generate strategy
    generateStrategy(formData);
  };
  
  // If a strategy has been generated, show the result
  if (generatedStrategy) {
    return (
      <StrategyResult 
        strategy={generatedStrategy.strategy}
        videoUrl={generatedStrategy.generatedVideo}
        onReset={clearGeneratedStrategy}
      />
    );
  }
  
  return (
    <form className="space-y-6" onSubmit={handleSubmit}>
      {/* Player Tag Input - Lookup player profile */}
      <div className="mb-6">
        <PlayerTagInput onPlayerDataLoaded={handlePlayerDataLoaded} />
      </div>
      
      {/* Show player profile if loaded */}
      {formData.playerData && (
        <div className="mb-6">
          <PlayerProfile playerData={formData.playerData} />
        </div>
      )}
      
      {/* Town Hall Selection */}
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <Label className="block text-sm font-medium mb-2">Your Town Hall Level</Label>
          <Select
            value={formData.userTownHallLevel}
            onValueChange={(value) => handleInputChange("userTownHallLevel", value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select Town Hall Level" />
            </SelectTrigger>
            <SelectContent>
              {TOWN_HALL_LEVELS.map((level) => (
                <SelectItem key={level.value} value={level.value}>
                  {level.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label className="block text-sm font-medium mb-2">Opponent's Town Hall Level</Label>
          <Select
            value={formData.opponentTownHallLevel}
            onValueChange={(value) => handleInputChange("opponentTownHallLevel", value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select Town Hall Level" />
            </SelectTrigger>
            <SelectContent>
              {TOWN_HALL_LEVELS.map((level) => (
                <SelectItem key={level.value} value={level.value}>
                  {level.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Available Troops */}
      <div>
        <Label className="block text-sm font-medium mb-2">Available Troops</Label>
        <TroopSelection
          troops={formData.troops}
          onTroopSelectionChange={handleTroopSelectionChange}
        />
      </div>
      
      {/* Available Spells */}
      <div>
        <Label className="block text-sm font-medium mb-2">Available Spells</Label>
        <SpellSelection
          spells={formData.spells}
          onSpellSelectionChange={handleSpellSelectionChange}
        />
      </div>
      
      {/* Hero Levels */}
      <div>
        <Label className="block text-sm font-medium mb-2">Hero Levels</Label>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {HEROES.map((hero) => (
            <div key={hero.id}>
              <Label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">
                {hero.name}
              </Label>
              <Input
                type="number"
                min="0"
                max={hero.maxLevel}
                placeholder={`Level (0-${hero.maxLevel})`}
                value={formData.heroes.find(h => h.id === hero.id)?.level || ""}
                onChange={(e) => handleHeroLevelChange(hero.id, parseInt(e.target.value) || 0)}
              />
            </div>
          ))}
        </div>
      </div>
      
      {/* Screenshot Upload & Generate Video */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label className="block text-sm font-medium mb-2">
            Upload Screenshot for Autofill (Optional)
          </Label>
          <FileInput
            onFileChange={(file) => handleInputChange("screenshot", file)}
            accept="image/*"
          />
        </div>
        
        <div>
          <Label className="block text-sm font-medium mb-2">Additional Options</Label>
          <div className="mt-1 space-y-4">
            <div className="flex items-center">
              <Switch
                checked={formData.generateVideo}
                onCheckedChange={(checked) => handleInputChange("generateVideo", checked)}
                id="generate-video"
              />
              <Label htmlFor="generate-video" className="ml-3 text-sm">
                Generate Strategy Video
              </Label>
            </div>
            
            <div className="flex items-center">
              <Switch
                checked={formData.includeDetailedGuide}
                onCheckedChange={(checked) => handleInputChange("includeDetailedGuide", checked)}
                id="detailed-guide"
              />
              <Label htmlFor="detailed-guide" className="ml-3 text-sm">
                Include Detailed Step-by-Step Guide
              </Label>
            </div>
          </div>
        </div>
      </div>
      
      {/* Generate Button */}
      <div className="pt-4">
        <Button
          type="submit"
          className="w-full bg-[#FF6B3D] hover:bg-orange-600 text-white font-bold py-3 px-4 rounded-md shadow-md flex items-center justify-center transition-colors duration-300"
          disabled={isGenerating}
        >
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Generating Strategy...
            </>
          ) : (
            <>
              <RocketIcon className="mr-2 h-5 w-5" />
              Generate Strategy
            </>
          )}
        </Button>
        
        {error && (
          <p className="text-red-500 text-sm mt-2">
            Error: {error instanceof Error ? error.message : "Something went wrong"}
          </p>
        )}
      </div>
    </form>
  );
}
