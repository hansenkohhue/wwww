import { useState } from "react";
import { Spell } from "@/lib/types";

interface SpellSelectionProps {
  spells: Spell[];
  onSpellSelectionChange: (selectedSpells: Spell[]) => void;
  showAllByDefault?: boolean;
}

export function SpellSelection({ 
  spells, 
  onSpellSelectionChange,
  showAllByDefault = false
}: SpellSelectionProps) {
  const [showAll, setShowAll] = useState(showAllByDefault);
  const [selectedSpells, setSelectedSpells] = useState<Spell[]>([]);

  const displayedSpells = showAll ? spells : spells.slice(0, 6);

  const toggleSpell = (spellId: string) => {
    const updatedSpells = [...selectedSpells];
    const spellIndex = updatedSpells.findIndex(s => s.id === spellId);
    
    if (spellIndex >= 0) {
      // Remove spell if already selected
      updatedSpells.splice(spellIndex, 1);
    } else {
      // Add spell if not selected
      const spellToAdd = spells.find(s => s.id === spellId);
      if (spellToAdd) {
        updatedSpells.push({ ...spellToAdd, selected: true });
      }
    }
    
    setSelectedSpells(updatedSpells);
    onSpellSelectionChange(updatedSpells);
  };

  const isSpellSelected = (spellId: string) => {
    return selectedSpells.some(s => s.id === spellId);
  };

  return (
    <div className="bg-gray-50 dark:bg-dark-100 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
        {displayedSpells.map((spell) => (
          <div key={spell.id} className="flex flex-col items-center">
            <div 
              className={`
                w-12 h-12 rounded-full flex items-center justify-center mb-1 cursor-pointer
                ${isSpellSelected(spell.id) 
                  ? "bg-[#1F8BFF] dark:bg-[#FFD54F] text-white dark:text-black" 
                  : "bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600"}
              `}
              onClick={() => toggleSpell(spell.id)}
            >
              <span className="material-icons">{spell.icon}</span>
            </div>
            <span className="text-xs text-center">{spell.name}</span>
          </div>
        ))}
      </div>
      
      {spells.length > 6 && (
        <div className="mt-3">
          <button 
            type="button" 
            className="text-sm text-[#1F8BFF] dark:text-[#FFD54F] hover:underline"
            onClick={() => setShowAll(!showAll)}
          >
            {showAll ? "Show less spells" : "Show all spells"}
          </button>
        </div>
      )}
    </div>
  );
}
