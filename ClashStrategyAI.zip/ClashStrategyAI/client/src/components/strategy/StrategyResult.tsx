import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { GeneratedStrategy } from "@/lib/types";
import { RefreshCcw, Video, Award, AlertTriangle, ChevronLeft } from "lucide-react";

interface StrategyResultProps {
  strategy: GeneratedStrategy;
  videoUrl: string | null;
  onReset: () => void;
}

export function StrategyResult({ strategy, videoUrl, onReset }: StrategyResultProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onReset} className="flex items-center">
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back to Generator
        </Button>
        <Badge variant="outline" className="px-3 py-1 text-sm">
          Success Rate: {strategy.successRate}%
        </Badge>
      </div>
      
      <Card>
        <CardHeader className="bg-gradient-to-r from-[#1F8BFF]/10 to-transparent dark:from-[#FFD54F]/10 pb-2">
          <CardTitle className="text-2xl font-bold">{strategy.name}</CardTitle>
          <CardDescription className="text-base">{strategy.description}</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Army Composition */}
            <div>
              <h3 className="text-lg font-semibold mb-3 flex items-center">
                <Award className="mr-2 h-5 w-5 text-[#1F8BFF] dark:text-[#FFD54F]" />
                Army Composition
              </h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                    Troops
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    {strategy.composition.troops.map((troop, index) => (
                      <div key={index} className="flex justify-between items-center bg-gray-50 dark:bg-dark-100 p-2 rounded">
                        <span>{troop.name}</span>
                        <Badge variant="secondary">{troop.count}x</Badge>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                    Spells
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    {strategy.composition.spells.map((spell, index) => (
                      <div key={index} className="flex justify-between items-center bg-gray-50 dark:bg-dark-100 p-2 rounded">
                        <span>{spell.name}</span>
                        <Badge variant="secondary">{spell.count}x</Badge>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                    Hero Usage
                  </h4>
                  <div className="bg-gray-50 dark:bg-dark-100 p-3 rounded text-sm">
                    {strategy.heroUsage}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Attack Steps */}
            <div>
              <h3 className="text-lg font-semibold mb-3">Attack Steps</h3>
              <ol className="space-y-3 list-decimal pl-5">
                {strategy.steps.map((step, index) => (
                  <li key={index} className="text-sm">
                    {step}
                  </li>
                ))}
              </ol>
              
              <Separator className="my-4" />
              
              <h3 className="text-lg font-semibold mb-3 flex items-center">
                <AlertTriangle className="mr-2 h-5 w-5 text-amber-500" />
                Common Mistakes to Avoid
              </h3>
              <ul className="space-y-2 list-disc pl-5">
                {strategy.commonMistakes.map((mistake, index) => (
                  <li key={index} className="text-sm text-red-600 dark:text-red-400">
                    {mistake}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          {/* Video (if available) */}
          {videoUrl && (
            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center">
                <Video className="mr-2 h-5 w-5 text-[#1F8BFF] dark:text-[#FFD54F]" />
                Strategy Video
              </h3>
              <div className="bg-gray-200 dark:bg-gray-800 aspect-video rounded-lg flex items-center justify-center">
                <p className="text-center text-gray-500 dark:text-gray-400">
                  Your strategy video is being generated. 
                  <br />
                  It will be available shortly.
                </p>
              </div>
            </div>
          )}
          
          <div className="mt-8 flex justify-center">
            <Button
              className="coc-btn-primary"
              onClick={() => window.print()}
            >
              Save Strategy
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
