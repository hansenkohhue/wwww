import { useState } from "react";
import { Troop } from "@/lib/types";

interface TroopSelectionProps {
  troops: Troop[];
  onTroopSelectionChange: (selectedTroops: Troop[]) => void;
  showAllByDefault?: boolean;
}

export function TroopSelection({ 
  troops, 
  onTroopSelectionChange,
  showAllByDefault = false
}: TroopSelectionProps) {
  const [showAll, setShowAll] = useState(showAllByDefault);
  const [selectedTroops, setSelectedTroops] = useState<Troop[]>([]);

  const displayedTroops = showAll ? troops : troops.slice(0, 6);

  const toggleTroop = (troopId: string) => {
    const updatedTroops = [...selectedTroops];
    const troopIndex = updatedTroops.findIndex(t => t.id === troopId);
    
    if (troopIndex >= 0) {
      // Remove troop if already selected
      updatedTroops.splice(troopIndex, 1);
    } else {
      // Add troop if not selected
      const troopToAdd = troops.find(t => t.id === troopId);
      if (troopToAdd) {
        updatedTroops.push({ ...troopToAdd, selected: true });
      }
    }
    
    setSelectedTroops(updatedTroops);
    onTroopSelectionChange(updatedTroops);
  };

  const isTroopSelected = (troopId: string) => {
    return selectedTroops.some(t => t.id === troopId);
  };

  return (
    <div className="bg-gray-50 dark:bg-dark-100 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
        {displayedTroops.map((troop) => (
          <div key={troop.id} className="flex flex-col items-center">
            <div 
              className={`
                w-12 h-12 rounded-full flex items-center justify-center mb-1 cursor-pointer
                ${isTroopSelected(troop.id) 
                  ? "bg-[#1F8BFF] dark:bg-[#FFD54F] text-white dark:text-black" 
                  : "bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600"}
              `}
              onClick={() => toggleTroop(troop.id)}
            >
              <span className="material-icons">{troop.icon}</span>
            </div>
            <span className="text-xs text-center">{troop.name}</span>
          </div>
        ))}
      </div>
      
      {troops.length > 6 && (
        <div className="mt-3">
          <button 
            type="button" 
            className="text-sm text-[#1F8BFF] dark:text-[#FFD54F] hover:underline"
            onClick={() => setShowAll(!showAll)}
          >
            {showAll ? "Show less troops" : "Show all troops"}
          </button>
        </div>
      )}
    </div>
  );
}
