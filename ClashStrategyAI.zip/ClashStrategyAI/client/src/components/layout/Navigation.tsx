import { useState } from "react";
import { Link, useLocation } from "wouter";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { Menu, X } from "lucide-react";

export function Navigation() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const navItems = [
    { path: "/", label: "Strategy Generator" },
    { path: "/latest", label: "Latest Strategies" },
    { path: "/subscription", label: "Subscription" },
  ];

  return (
    <header className="bg-white dark:bg-dark-200 shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center">
          <Link href="/" className="flex items-center">
            <div className="w-10 h-10 rounded-lg bg-[#FF6B3D] flex items-center justify-center mr-2">
              <span className="material-icons text-white">flash_on</span>
            </div>
            <span className="text-xl font-bold">Clash Strategy AI</span>
          </Link>
        </div>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-6">
          {navItems.map((item) => (
            <Link 
              key={item.path} 
              href={item.path}
              className={`font-medium py-1 ${
                location === item.path 
                  ? "text-[#1F8BFF] dark:text-[#FFD54F] border-b-2 border-[#1F8BFF] dark:border-[#FFD54F]" 
                  : "text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        
        {/* Theme Toggle and Mobile Menu */}
        <div className="flex items-center space-x-4">
          <ThemeToggle />
          
          {/* Mobile menu button */}
          <button 
            className="md:hidden focus:outline-none"
            onClick={toggleMobileMenu}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation (Hidden by default) */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-dark-200">
          <div className="container mx-auto px-4 py-2 space-y-2">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <a 
                  className={`block py-2 px-4 font-medium rounded ${
                    location === item.path 
                      ? "text-[#1F8BFF] dark:text-[#FFD54F] bg-gray-100 dark:bg-dark-100" 
                      : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-100"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </a>
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
