import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-white dark:bg-dark-200 border-t border-gray-200 dark:border-dark-100 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Clash Strategy AI</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Advanced AI-powered attack strategies for Clash of Clans players of all levels.
            </p>
          </div>
          
          <div>
            <h3 className="text-sm font-bold uppercase text-gray-500 dark:text-gray-400 mb-4">
              Features
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/">
                  <a className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                    Strategy Generator
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/latest">
                  <a className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                    Latest Strategies
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/subscription">
                  <a className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                    Subscription Plans
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/">
                  <a className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                    Base Scanner
                  </a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-bold uppercase text-gray-500 dark:text-gray-400 mb-4">
              Resources
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                  Strategy Guides
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                  Community Forum
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                  Contact Support
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-bold uppercase text-gray-500 dark:text-gray-400 mb-4">
              Legal
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-[#1F8BFF] dark:hover:text-[#FFD54F]">
                  Cookie Policy
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 text-center text-sm text-gray-500 dark:text-gray-400">
          <p>© 2023 Clash Strategy AI. Not affiliated with Supercell. Clash of Clans is a trademark of Supercell.</p>
        </div>
      </div>
    </footer>
  );
}
