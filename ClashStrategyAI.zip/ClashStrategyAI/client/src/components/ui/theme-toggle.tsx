import { useTheme } from "@/context/ThemeContext";
import { SunIcon, MoonIcon } from "lucide-react";

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  
  return (
    <div className="flex items-center space-x-2">
      <SunIcon className="h-4 w-4 text-gray-600 dark:text-gray-300" />
      <label className="relative inline-flex items-center cursor-pointer">
        <input
          type="checkbox"
          className="sr-only"
          checked={theme === "dark"}
          onChange={toggleTheme}
        />
        <div className={`
          relative w-14 h-7 rounded-full 
          transition-colors duration-300 ease-in-out
          ${theme === "dark" ? "bg-[#1F8BFF]" : "bg-[#E0E0E0]"}
        `}>
          <div className={`
            absolute top-1 left-1 bg-white w-5 h-5 rounded-full 
            transition-transform duration-300 ease-in-out
            ${theme === "dark" ? "transform translate-x-7" : ""}
          `}></div>
        </div>
      </label>
      <MoonIcon className="h-4 w-4 text-gray-600 dark:text-gray-300" />
    </div>
  );
}
