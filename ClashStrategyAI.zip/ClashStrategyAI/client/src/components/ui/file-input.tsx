import { ChangeEvent, useState } from "react";
import { Button } from "@/components/ui/button";
import { Upload, FileX } from "lucide-react";

interface FileInputProps {
  onFileChange: (file: File | null) => void;
  accept?: string;
  maxSize?: number; // in bytes
  label?: string;
  className?: string;
}

export function FileInput({
  onFileChange,
  accept = "image/*",
  maxSize = 10 * 1024 * 1024, // 10MB default
  label = "Upload a file",
  className = "",
}: FileInputProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0] || null;
    validateAndSetFile(selectedFile);
  };

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
    
    const droppedFile = event.dataTransfer.files?.[0] || null;
    validateAndSetFile(droppedFile);
  };

  const validateAndSetFile = (selectedFile: File | null) => {
    setError(null);
    
    if (!selectedFile) {
      setFile(null);
      onFileChange(null);
      return;
    }
    
    // Check file size
    if (selectedFile.size > maxSize) {
      setError(`File too large. Maximum size is ${(maxSize / (1024 * 1024)).toFixed(1)}MB`);
      return;
    }
    
    // Check file type if accept is specified
    if (accept !== "image/*" && !accept.includes(selectedFile.type)) {
      setError(`Invalid file type. Please upload ${accept.split(",").join(" or ")}`);
      return;
    }
    
    setFile(selectedFile);
    onFileChange(selectedFile);
  };

  const clearFile = () => {
    setFile(null);
    onFileChange(null);
    setError(null);
  };

  return (
    <div className={className}>
      {!file ? (
        <div
          className={`
            mt-1 flex justify-center px-6 pt-5 pb-6 border-2 
            ${isDragging ? "border-[#1F8BFF] dark:border-[#FFD54F]" : "border-gray-300 dark:border-gray-600"} 
            ${error ? "border-red-500" : ""}
            border-dashed rounded-md transition-colors duration-200
          `}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <div className="space-y-1 text-center">
            <Upload className="mx-auto h-12 w-12 text-gray-400" />
            <div className="flex text-sm text-gray-600 dark:text-gray-400">
              <label
                htmlFor="file-upload"
                className="relative cursor-pointer rounded-md font-medium text-[#1F8BFF] dark:text-[#FFD54F] hover:underline"
              >
                <span>{label}</span>
                <input
                  id="file-upload"
                  name="file-upload"
                  type="file"
                  className="sr-only"
                  onChange={handleFileChange}
                  accept={accept}
                />
              </label>
              <p className="pl-1">or drag and drop</p>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {accept === "image/*" ? "PNG, JPG, GIF up to 10MB" : accept.split(",").join(", ")}
            </p>
            {error && <p className="text-sm text-red-500">{error}</p>}
          </div>
        </div>
      ) : (
        <div className="mt-1 flex items-center p-2 border border-gray-300 dark:border-gray-600 rounded-md">
          <div className="flex-1 truncate">
            <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
              {file.name}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {(file.size / 1024).toFixed(1)} KB
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFile}
            className="ml-2 text-gray-500 hover:text-red-500"
          >
            <FileX className="h-5 w-5" />
          </Button>
        </div>
      )}
    </div>
  );
}
