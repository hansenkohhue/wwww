import { Badge } from "@/components/ui/badge";
import { LatestStrategy } from "@/lib/types";
import { CalendarIcon, Gamepad2 } from "lucide-react";

interface StrategyCardProps {
  strategy: LatestStrategy;
}

export function StrategyCard({ strategy }: StrategyCardProps) {
  const getSuccessRateColor = (rate: number) => {
    if (rate >= 90) return "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200";
    if (rate >= 80) return "bg-lime-100 dark:bg-lime-900 text-lime-800 dark:text-lime-200";
    if (rate >= 70) return "bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200";
    return "bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-200";
  };
  
  const getTimeAgo = (days: number) => {
    if (days === 0) return "Today";
    if (days === 1) return "Yesterday";
    if (days < 7) return `${days} days ago`;
    if (days < 30) return `${Math.floor(days / 7)} week${Math.floor(days / 7) > 1 ? 's' : ''} ago`;
    return `${Math.floor(days / 30)} month${Math.floor(days / 30) > 1 ? 's' : ''} ago`;
  };

  return (
    <div className="bg-gray-50 dark:bg-dark-100 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300">
      <div className="h-48 bg-gray-200 dark:bg-gray-700 relative">
        <div className="absolute inset-0 flex items-center justify-center text-gray-400 dark:text-gray-500">
          <Gamepad2 className="h-16 w-16" />
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg mb-2">{strategy.title}</h3>
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-3">
          <CalendarIcon className="h-4 w-4 mr-1" />
          <span>Added {getTimeAgo(strategy.addedDays)}</span>
        </div>
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
          {strategy.description}
        </p>
        <div className="flex items-center justify-between">
          <Badge className={getSuccessRateColor(strategy.successRate)}>
            {strategy.successRate}%+ Success
          </Badge>
          <button className="text-[#1F8BFF] dark:text-[#FFD54F] hover:underline text-sm font-medium">
            View Strategy
          </button>
        </div>
      </div>
    </div>
  );
}
