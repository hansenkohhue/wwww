import { Button } from "@/components/ui/button";
import { StrategyCard } from "./StrategyCard";
import { LatestStrategy } from "@/lib/types";
import { ArrowDown } from "lucide-react";
import { useState } from "react";

interface LatestStrategiesProps {
  strategies: LatestStrategy[];
  initialCount?: number;
}

export function LatestStrategies({ 
  strategies, 
  initialCount = 3 
}: LatestStrategiesProps) {
  const [displayCount, setDisplayCount] = useState(initialCount);
  const hasMore = displayCount < strategies.length;
  
  const loadMore = () => {
    setDisplayCount(prev => Math.min(prev + 3, strategies.length));
  };
  
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {strategies.slice(0, displayCount).map((strategy) => (
          <StrategyCard key={strategy.id} strategy={strategy} />
        ))}
      </div>
      
      {hasMore && (
        <div className="mt-8 text-center">
          <Button
            onClick={loadMore}
            className="inline-flex items-center justify-center px-5 py-2 border border-transparent text-base font-medium rounded-md text-white bg-[#1F8BFF] hover:bg-blue-600 dark:bg-[#FF6B3D] dark:hover:bg-orange-600"
          >
            Load More Strategies
            <ArrowDown className="ml-2 h-5 w-5" />
          </Button>
        </div>
      )}
    </div>
  );
}
