import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

interface PlayerProfileProps {
  playerData: any;
}

export function PlayerProfile({ playerData }: PlayerProfileProps) {
  if (!playerData) return null;

  return (
    <Card className="mb-6">
      <CardHeader className="pb-3">
        <div className="flex items-center space-x-4">
          <Avatar className="h-16 w-16 border-2 border-[#1F8BFF] dark:border-[#FFD54F]">
            {playerData.clan?.badgeUrl ? (
              <AvatarImage src={playerData.clan.badgeUrl} alt="Clan badge" />
            ) : (
              <AvatarFallback className="bg-gray-200 dark:bg-gray-700 text-xl">
                {playerData.name?.substring(0, 2).toUpperCase() || "??"}
              </AvatarFallback>
            )}
          </Avatar>
          <div>
            <CardTitle className="text-xl">{playerData.name}</CardTitle>
            <CardDescription>
              {playerData.tag} • TH{playerData.townHallLevel}
            </CardDescription>
            {playerData.clan && (
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                Clan: {playerData.clan.name} (Level {playerData.clan.level})
              </p>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center mb-4">
          <div className="bg-gray-50 dark:bg-dark-100 p-3 rounded-lg">
            <p className="text-sm text-gray-500 dark:text-gray-400">Trophies</p>
            <p className="text-lg font-semibold">{playerData.trophies}</p>
          </div>
          <div className="bg-gray-50 dark:bg-dark-100 p-3 rounded-lg">
            <p className="text-sm text-gray-500 dark:text-gray-400">War Stars</p>
            <p className="text-lg font-semibold">{playerData.warStars}</p>
          </div>
          <div className="bg-gray-50 dark:bg-dark-100 p-3 rounded-lg">
            <p className="text-sm text-gray-500 dark:text-gray-400">Attack Wins</p>
            <p className="text-lg font-semibold">{playerData.attackWins}</p>
          </div>
          <div className="bg-gray-50 dark:bg-dark-100 p-3 rounded-lg">
            <p className="text-sm text-gray-500 dark:text-gray-400">Defense Wins</p>
            <p className="text-lg font-semibold">{playerData.defenseWins}</p>
          </div>
        </div>
        
        <Separator className="my-4" />
        
        <div>
          <h4 className="font-medium mb-2">Troop Levels</h4>
          <div className="flex flex-wrap gap-2 mb-4">
            {playerData.troops?.slice(0, 8).map((troop: any, index: number) => (
              <Badge key={index} variant="outline" className="flex items-center gap-1">
                {troop.name}
                <span className="bg-[#1F8BFF] dark:bg-[#FFD54F] text-white dark:text-black px-1.5 py-0.5 rounded-sm text-xs">
                  Lv{troop.level}
                </span>
              </Badge>
            ))}
            {playerData.troops?.length > 8 && (
              <Badge variant="outline">+{playerData.troops.length - 8} more</Badge>
            )}
          </div>
          
          <h4 className="font-medium mb-2">Hero Levels</h4>
          <div className="flex flex-wrap gap-2">
            {playerData.heroes?.map((hero: any, index: number) => (
              <Badge key={index} variant="outline" className="flex items-center gap-1">
                {hero.name}
                <span className="bg-[#1F8BFF] dark:bg-[#FFD54F] text-white dark:text-black px-1.5 py-0.5 rounded-sm text-xs">
                  Lv{hero.level}
                </span>
              </Badge>
            ))}
            {!playerData.heroes?.length && (
              <p className="text-sm text-gray-500 dark:text-gray-400">No heroes found</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}