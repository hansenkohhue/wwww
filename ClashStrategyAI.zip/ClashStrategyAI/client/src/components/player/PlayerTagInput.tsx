import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Search } from "lucide-react";

interface PlayerTagInputProps {
  onPlayerDataLoaded: (playerData: any) => void;
}

export function PlayerTagInput({ onPlayerDataLoaded }: PlayerTagInputProps) {
  const [playerTag, setPlayerTag] = useState<string>("");
  const { toast } = useToast();

  // Mutation for fetching player data
  const fetchPlayerMutation = useMutation({
    mutationFn: async (tag: string) => {
      // Format the tag: remove spaces and ensure it starts with '#'
      let formattedTag = tag.trim();
      if (!formattedTag.startsWith("#")) {
        formattedTag = "#" + formattedTag;
      }
      
      // URL encode the tag for the API call
      const encodedTag = encodeURIComponent(formattedTag);
      
      const response = await apiRequest("GET", `/api/coc/player/${encodedTag}`);
      return await response.json();
    },
    onSuccess: (data) => {
      onPlayerDataLoaded(data);
      toast({
        title: "Player data loaded!",
        description: `Successfully loaded data for ${data.name}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error loading player data",
        description: error.message || "Could not find player with that tag",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerTag) {
      toast({
        title: "Player tag required",
        description: "Please enter your Clash of Clans player tag",
        variant: "destructive",
      });
      return;
    }
    
    fetchPlayerMutation.mutate(playerTag);
  };

  return (
    <div className="bg-gray-50 dark:bg-dark-100 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
      <h3 className="text-lg font-medium mb-2">Load Player Data</h3>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
        Enter your Clash of Clans player tag to automatically fill in your troop and hero levels.
      </p>
      
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            type="text"
            placeholder="Enter player tag (e.g. #ABC123)"
            value={playerTag}
            onChange={(e) => setPlayerTag(e.target.value)}
            className="pl-8"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
          />
          <span className="absolute left-2.5 top-2.5 text-gray-400">#</span>
        </div>
        <Button 
          type="button" 
          onClick={handleSubmit}
          disabled={fetchPlayerMutation.isPending}
          className="bg-[#1F8BFF] dark:bg-[#FFD54F] text-white dark:text-black hover:bg-blue-600 dark:hover:bg-yellow-500"
        >
          {fetchPlayerMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Loading...
            </>
          ) : (
            <>
              <Search className="mr-2 h-4 w-4" />
              Load Data
            </>
          )}
        </Button>
      </div>
      
      {fetchPlayerMutation.isError && (
        <p className="mt-2 text-sm text-red-500">
          {(fetchPlayerMutation.error as Error)?.message || "Error loading player data"}
        </p>
      )}
    </div>
  );
}