import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { StrategyFormData, StrategyResponse } from "@/lib/types";

export function useStrategy() {
  const [generatedStrategy, setGeneratedStrategy] = useState<StrategyResponse | null>(null);

  const generateStrategyMutation = useMutation({
    mutationFn: async (formData: StrategyFormData) => {
      // Prepare the payload
      const payload = {
        userTownHallLevel: formData.userTownHallLevel,
        opponentTownHallLevel: formData.opponentTownHallLevel,
        troops: formData.troops.filter(troop => troop.selected).map(troop => ({
          id: troop.id,
          name: troop.name,
          level: troop.level || 1
        })),
        spells: formData.spells.filter(spell => spell.selected).map(spell => ({
          id: spell.id,
          name: spell.name,
          level: spell.level || 1
        })),
        heroes: formData.heroes.filter(hero => hero.level && hero.level > 0).map(hero => ({
          id: hero.id,
          name: hero.name,
          level: hero.level
        })),
        generateVideo: formData.generateVideo
      };

      // Send request to generate strategy
      const response = await apiRequest("POST", "/api/generate-strategy", payload);
      const data: StrategyResponse = await response.json();
      
      // Store the generated strategy
      setGeneratedStrategy(data);
      
      return data;
    },
  });

  const clearGeneratedStrategy = () => {
    setGeneratedStrategy(null);
  };

  return {
    generateStrategy: generateStrategyMutation.mutate,
    isGenerating: generateStrategyMutation.isPending,
    error: generateStrategyMutation.error,
    generatedStrategy,
    clearGeneratedStrategy
  };
}
