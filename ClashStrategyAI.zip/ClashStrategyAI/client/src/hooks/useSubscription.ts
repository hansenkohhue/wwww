import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQuery } from "@tanstack/react-query";
import { SubscriptionPlan } from "@/lib/types";
import { SUBSCRIPTION_PLANS } from "@/lib/constants";

interface SubscribeParams {
  userId: number;
  planId: number;
}

export function useSubscription() {
  const [currentPlan, setCurrentPlan] = useState<SubscriptionPlan | null>(null);
  const [trialEndDate, setTrialEndDate] = useState<Date | null>(null);

  // Get subscription plans
  const plansQuery = useQuery({
    queryKey: ["/api/subscription-plans"],
    initialData: SUBSCRIPTION_PLANS, // Use constants as initial data
  });

  // Subscribe to a plan
  const subscribeMutation = useMutation({
    mutationFn: async ({ userId, planId }: SubscribeParams) => {
      const response = await apiRequest("POST", "/api/subscribe", { userId, planId });
      const data = await response.json();
      
      // Update current plan and trial end date
      const selectedPlan = plansQuery.data.find(plan => plan.id === planId) || null;
      setCurrentPlan(selectedPlan);
      
      if (data.trialEnd) {
        setTrialEndDate(new Date(data.trialEnd));
      }
      
      return data;
    },
  });

  return {
    plans: plansQuery.data,
    isLoadingPlans: plansQuery.isLoading,
    currentPlan,
    trialEndDate,
    subscribe: subscribeMutation.mutate,
    isSubscribing: subscribeMutation.isPending,
    subscribeError: subscribeMutation.error,
  };
}
