import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/context/ThemeContext";
import Home from "@/pages/home";
import Latest from "@/pages/latest";
import Subscription from "@/pages/subscription";
import Strategy from "@/pages/strategy";
import Checkout from "@/pages/checkout";
import NotFound from "@/pages/not-found";
import { Helmet } from "react-helmet-async";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/latest" component={Latest} />
      <Route path="/subscription" component={Subscription} />
      <Route path="/strategy" component={Strategy} />
      <Route path="/checkout" component={Checkout} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Helmet>
            <title>Clash Strategy AI | Advanced Attack Strategies for Clash of Clans</title>
            <meta name="description" content="Get AI-powered attack strategies for Clash of Clans. Generate custom strategies based on your town hall level, troops, and heroes." />
            <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
            <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet" />
            <meta property="og:title" content="Clash Strategy AI | Advanced Attack Strategies" />
            <meta property="og:description" content="Get AI-powered attack strategies for Clash of Clans" />
            <meta property="og:type" content="website" />
          </Helmet>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
