import { MainLayout } from "@/components/layout/MainLayout";
import { LatestStrategies } from "@/components/latest/LatestStrategies";
import { LATEST_STRATEGIES } from "@/lib/constants";
import { Helmet } from "react-helmet-async";

export default function Latest() {
  return (
    <MainLayout>
      <Helmet>
        <title>Latest Strategies | Clash Strategy AI</title>
        <meta name="description" content="Browse the latest and most effective Clash of Clans attack strategies for all Town Hall levels." />
      </Helmet>
      
      <div className="bg-white dark:bg-dark-200 rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
          Latest Strategies
        </h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          Browse through our collection of the latest and most effective attack strategies.
        </p>
        
        <LatestStrategies strategies={LATEST_STRATEGIES} />
      </div>
    </MainLayout>
  );
}
