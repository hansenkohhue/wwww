import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useLocation } from 'wouter';

// This will be replaced with Stripe Elements when API keys are provided
export default function Checkout() {
  const { toast } = useToast();
  const [_, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);

  // Simulate fetching the selected plan
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const planId = params.get('plan');
    
    if (planId) {
      // Fetch plan details (this would be a real API call in production)
      setSelectedPlan({
        id: parseInt(planId),
        name: planId === '1' ? 'Basic' : planId === '2' ? 'Pro' : 'Ultimate',
        price: planId === '1' ? 9.99 : planId === '2' ? 19.99 : 29.99,
        features: [
          'Access to AI strategy generation',
          'Player tag lookup',
          planId !== '1' && 'Video generation',
          planId === '3' && 'Priority support',
        ].filter(Boolean),
      });
    } else {
      // Redirect if no plan selected
      setLocation('/subscription');
    }
  }, [setLocation]);

  const handlePayment = async () => {
    try {
      setLoading(true);
      
      // Placeholder for Stripe integration
      // This would be replaced with actual Stripe payment processing
      
      setTimeout(() => {
        toast({
          title: "Payment successful!",
          description: "You're now subscribed to the " + selectedPlan.name + " plan. Enjoy!",
        });
        
        // Redirect to strategies page after successful payment
        setLocation('/strategy');
        setLoading(false);
      }, 1500);
      
    } catch (error) {
      console.error('Payment error:', error);
      toast({
        title: "Payment failed",
        description: "There was an issue processing your payment. Please try again.",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  if (!selectedPlan) {
    return (
      <MainLayout>
        <div className="container mx-auto py-8">
          <div className="flex items-center justify-center h-40">
            <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-bold mb-6">Complete Your Purchase</h1>
        
        <div className="grid md:grid-cols-2 gap-8">
          {/* Order Summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
                <CardDescription>Review your subscription details</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="font-medium">{selectedPlan.name} Plan</span>
                    <span>${selectedPlan.price.toFixed(2)}/month</span>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <p className="font-medium">Features included:</p>
                    <ul className="list-disc list-inside space-y-1">
                      {selectedPlan.features.map((feature: string, index: number) => (
                        <li key={index} className="text-sm text-gray-600 dark:text-gray-400">
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between font-bold">
                    <span>Total</span>
                    <span>${selectedPlan.price.toFixed(2)}/month</span>
                  </div>
                  
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    Your subscription will begin with a 7-day free trial. You won't be charged until after your trial ends.
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Payment Details */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
                <CardDescription>Secure payment processing with Stripe</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-6 border border-dashed border-gray-300 dark:border-gray-700 rounded-lg text-center">
                    <p className="text-gray-500 dark:text-gray-400 mb-2">
                      Payment processing will be enabled when Stripe integration is complete.
                    </p>
                    <div className="flex flex-wrap gap-2 justify-center">
                      <div className="bg-gray-100 dark:bg-gray-800 p-2 rounded">
                        <span className="text-sm font-medium">Credit Card</span>
                      </div>
                      <div className="bg-gray-100 dark:bg-gray-800 p-2 rounded">
                        <span className="text-sm font-medium">Apple Pay</span>
                      </div>
                      <div className="bg-gray-100 dark:bg-gray-800 p-2 rounded">
                        <span className="text-sm font-medium">Google Pay</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full bg-[#1F8BFF] hover:bg-blue-600 dark:bg-[#FFD54F] dark:text-black dark:hover:bg-yellow-500"
                  onClick={handlePayment}
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="mr-2">Processing</span>
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    </>
                  ) : (
                    'Start Free Trial'
                  )}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}