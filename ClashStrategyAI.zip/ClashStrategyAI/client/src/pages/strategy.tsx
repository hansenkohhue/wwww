import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { LATEST_STRATEGIES } from "@/lib/constants";
import { GeneratedStrategy } from "@/lib/types";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet-async";
import { 
  ChevronLeft, 
  Award, 
  Video, 
  AlertTriangle, 
  Download, 
  Share2 
} from "lucide-react";
import { Link } from "wouter";

export default function Strategy() {
  const [, params] = useRoute("/strategy/:id");
  const strategyId = params?.id ? parseInt(params.id) : null;
  
  // Fetch the strategy data
  const { data: strategy, isLoading, error } = useQuery({
    queryKey: [strategyId ? `/api/strategies/${strategyId}` : null],
    enabled: !!strategyId,
    // Fallback to local data for demonstration
    initialData: strategyId 
      ? {
          name: LATEST_STRATEGIES.find(s => s.id === strategyId)?.title || "",
          description: LATEST_STRATEGIES.find(s => s.id === strategyId)?.description || "",
          successRate: LATEST_STRATEGIES.find(s => s.id === strategyId)?.successRate || 0,
          composition: {
            troops: [
              { name: "Dragon Rider", count: 8 },
              { name: "Baby Dragon", count: 3 },
              { name: "Balloon", count: 8 },
              { name: "Minion", count: 5 }
            ],
            spells: [
              { name: "Lightning", count: 4 },
              { name: "Rage", count: 2 },
              { name: "Freeze", count: 1 }
            ]
          },
          steps: [
            "Use Lightning spells to take out one Air Defense.",
            "Deploy King and Queen to create a funnel on one side.",
            "Send in Dragon Riders with Balloons behind.",
            "Use Rage when troops reach the core of the base.",
            "Deploy remaining troops to clean up the outside.",
            "Save Royal Champion for late deployment to snipe defenses."
          ],
          heroUsage: "Use Barbarian King and Archer Queen to create a funnel. Grand Warden should follow the main attack force. Save Royal Champion for cleanup.",
          commonMistakes: [
            "Not creating a proper funnel",
            "Using all spells too early",
            "Deploying all troops in one spot",
            "Not timing Warden ability correctly"
          ],
          videoUrl: "https://example.com/video"
        } as GeneratedStrategy
      : undefined
  });

  if (isLoading) {
    return (
      <MainLayout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <Skeleton className="h-10 w-32" />
            <Skeleton className="h-6 w-24" />
          </div>
          
          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/2" />
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <Skeleton className="h-6 w-40 mb-2" />
                  <div className="space-y-2">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                </div>
                <div className="space-y-4">
                  <Skeleton className="h-6 w-40 mb-2" />
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-full" />
                    <Skeleton className="h-5 w-full" />
                    <Skeleton className="h-5 w-full" />
                    <Skeleton className="h-5 w-full" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  if (error || !strategy) {
    return (
      <MainLayout>
        <Card className="p-6">
          <CardTitle className="text-xl mb-4">Strategy Not Found</CardTitle>
          <CardDescription>
            The strategy you're looking for could not be found or an error occurred.
          </CardDescription>
          <div className="mt-4">
            <Link href="/latest">
              <Button>View All Strategies</Button>
            </Link>
          </div>
        </Card>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <Helmet>
        <title>{strategy.name} | Clash Strategy AI</title>
        <meta name="description" content={strategy.description} />
      </Helmet>

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Link href="/latest">
            <Button variant="outline" className="flex items-center">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Latest Strategies
            </Button>
          </Link>
          <Badge variant="outline" className="px-3 py-1 text-sm">
            Success Rate: {strategy.successRate}%
          </Badge>
        </div>
        
        <Card>
          <CardHeader className="bg-gradient-to-r from-[#1F8BFF]/10 to-transparent dark:from-[#FFD54F]/10 pb-2">
            <CardTitle className="text-2xl font-bold">{strategy.name}</CardTitle>
            <CardDescription className="text-base">{strategy.description}</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Army Composition */}
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center">
                  <Award className="mr-2 h-5 w-5 text-[#1F8BFF] dark:text-[#FFD54F]" />
                  Army Composition
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                      Troops
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      {strategy.composition.troops.map((troop, index) => (
                        <div key={index} className="flex justify-between items-center bg-gray-50 dark:bg-dark-100 p-2 rounded">
                          <span>{troop.name}</span>
                          <Badge variant="secondary">{troop.count}x</Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                      Spells
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      {strategy.composition.spells.map((spell, index) => (
                        <div key={index} className="flex justify-between items-center bg-gray-50 dark:bg-dark-100 p-2 rounded">
                          <span>{spell.name}</span>
                          <Badge variant="secondary">{spell.count}x</Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                      Hero Usage
                    </h4>
                    <div className="bg-gray-50 dark:bg-dark-100 p-3 rounded text-sm">
                      {strategy.heroUsage}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Attack Steps */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Attack Steps</h3>
                <ol className="space-y-3 list-decimal pl-5">
                  {strategy.steps.map((step, index) => (
                    <li key={index} className="text-sm">
                      {step}
                    </li>
                  ))}
                </ol>
                
                <Separator className="my-4" />
                
                <h3 className="text-lg font-semibold mb-3 flex items-center">
                  <AlertTriangle className="mr-2 h-5 w-5 text-amber-500" />
                  Common Mistakes to Avoid
                </h3>
                <ul className="space-y-2 list-disc pl-5">
                  {strategy.commonMistakes.map((mistake, index) => (
                    <li key={index} className="text-sm text-red-600 dark:text-red-400">
                      {mistake}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            {/* Video (if available) */}
            {strategy.videoUrl && (
              <div className="mt-6">
                <h3 className="text-lg font-semibold mb-3 flex items-center">
                  <Video className="mr-2 h-5 w-5 text-[#1F8BFF] dark:text-[#FFD54F]" />
                  Strategy Video
                </h3>
                <div className="bg-gray-200 dark:bg-gray-800 aspect-video rounded-lg flex items-center justify-center">
                  <p className="text-center text-gray-500 dark:text-gray-400">
                    Your strategy video is being generated. 
                    <br />
                    It will be available shortly.
                  </p>
                </div>
              </div>
            )}
            
            <div className="mt-8 flex justify-center space-x-4">
              <Button
                className="coc-btn-primary flex items-center"
                onClick={() => window.print()}
              >
                <Download className="mr-2 h-4 w-4" />
                Save Strategy
              </Button>
              
              <Button
                variant="outline"
                className="coc-btn-secondary flex items-center"
                onClick={() => {
                  navigator.clipboard.writeText(window.location.href);
                  alert("Strategy link copied to clipboard!");
                }}
              >
                <Share2 className="mr-2 h-4 w-4" />
                Share Strategy
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
