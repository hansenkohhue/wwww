import { MainLayout } from "@/components/layout/MainLayout";
import { PricingPlans } from "@/components/subscription/PricingPlans";
import { FrequentlyAskedQuestions } from "@/components/subscription/FrequentlyAskedQuestions";
import { SUBSCRIPTION_PLANS, FAQ_ITEMS } from "@/lib/constants";
import { Helmet } from "react-helmet-async";

export default function Subscription() {
  return (
    <MainLayout>
      <Helmet>
        <title>Subscription Plans | Clash Strategy AI</title>
        <meta name="description" content="Choose a subscription plan for Clash Strategy AI with a 7-day free trial. Get access to advanced strategies, video guides, and more." />
      </Helmet>
      
      <div className="bg-white dark:bg-dark-200 rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
          Subscription Plans
        </h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          Choose a plan that works for you. All plans include a 7-day free trial.
        </p>
        
        <PricingPlans plans={SUBSCRIPTION_PLANS} />
        
        <FrequentlyAskedQuestions faqItems={FAQ_ITEMS} />
      </div>
    </MainLayout>
  );
}
