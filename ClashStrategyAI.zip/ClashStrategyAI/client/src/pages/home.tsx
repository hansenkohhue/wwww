import { MainLayout } from "@/components/layout/MainLayout";
import { StrategyForm } from "@/components/strategy/StrategyForm";
import { Helmet } from "react-helmet-async";

export default function Home() {
  return (
    <MainLayout>
      <Helmet>
        <title>Strategy Generator | Clash Strategy AI</title>
        <meta name="description" content="Generate custom Clash of Clans attack strategies based on your town hall level, troops, and heroes." />
      </Helmet>
      
      <div className="bg-white dark:bg-dark-200 rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">
          Generate Your Perfect Attack Strategy
        </h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          Enter your details below to get a customized attack strategy for your next Clash of Clans battle.
        </p>
        
        <StrategyForm />
      </div>
    </MainLayout>
  );
}
