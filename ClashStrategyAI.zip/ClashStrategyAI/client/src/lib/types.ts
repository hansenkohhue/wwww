// Basic types
export interface TownHallLevel {
  value: string;
  label: string;
}

export interface Troop {
  id: string;
  name: string;
  icon: string;
  maxLevel: number;
  selected?: boolean;
  level?: number;
}

export interface Spell {
  id: string;
  name: string;
  icon: string;
  maxLevel: number;
  selected?: boolean;
  level?: number;
}

export interface Hero {
  id: string;
  name: string;
  maxLevel: number;
  level?: number;
}

// Form types
export interface StrategyFormData {
  userTownHallLevel: string;
  opponentTownHallLevel: string;
  troops: Troop[];
  spells: Spell[];
  heroes: Hero[];
  screenshot?: File;
  generateVideo: boolean;
  includeDetailedGuide: boolean;
  playerData?: any; // Player data from Clash of Clans API
}

// Strategy types
export interface StrategyStep {
  title: string;
  description: string;
}

export interface TroopComposition {
  troopId: string;
  name: string;
  count: number;
}

export interface SpellComposition {
  spellId: string;
  name: string;
  count: number;
}

export interface GeneratedStrategy {
  name: string;
  description: string;
  composition: {
    troops: TroopComposition[];
    spells: SpellComposition[];
  };
  steps: string[];
  heroUsage: string;
  commonMistakes: string[];
  successRate: number;
}

export interface StrategyResponse {
  strategy: GeneratedStrategy;
  generatedVideo: string | null;
}

// Subscription types
export interface PlanFeature {
  name: string;
  included: boolean;
}

export interface SubscriptionPlan {
  id: number;
  name: string;
  price: number;
  billingCycle: string;
  isMostPopular: boolean;
  features: PlanFeature[];
}

// Latest strategy types
export interface LatestStrategy {
  id: number;
  title: string;
  addedDays: number;
  description: string;
  successRate: number;
}

// FAQ type
export interface FAQItem {
  question: string;
  answer: string;
}
