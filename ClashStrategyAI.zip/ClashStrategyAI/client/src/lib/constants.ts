// Town Hall levels
export const TOWN_HALL_LEVELS = [
  { value: "14", label: "Town Hall 14" },
  { value: "13", label: "Town Hall 13" },
  { value: "12", label: "Town Hall 12" },
  { value: "11", label: "Town Hall 11" },
  { value: "10", label: "Town Hall 10" },
  { value: "9", label: "Town Hall 9" },
  { value: "8", label: "Town Hall 8" },
  { value: "7", label: "Town Hall 7" },
];

// Troops data
export const TROOPS = [
  { id: "barbarian", name: "Barbarian", icon: "person", maxLevel: 10 },
  { id: "archer", name: "Archer", icon: "female", maxLevel: 10 },
  { id: "giant", name: "Giant", icon: "fitness_center", maxLevel: 10 },
  { id: "goblin", name: "Goblin", icon: "directions_run", maxLevel: 8 },
  { id: "wallBreaker", name: "Wall Breaker", icon: "bomb", maxLevel: 10 },
  { id: "balloon", name: "Balloon", icon: "airplanemode_active", maxLevel: 10 },
  { id: "wizard", name: "Wizard", icon: "bolt", maxLevel: 10 },
  { id: "healer", name: "Healer", icon: "health_and_safety", maxLevel: 7 },
  { id: "dragon", name: "Dragon", icon: "local_fire_department", maxLevel: 9 },
  { id: "pekka", name: "P.E.K.K.A", icon: "auto_fix_high", maxLevel: 9 },
  { id: "babyDragon", name: "Baby Dragon", icon: "pets", maxLevel: 7 },
  { id: "miner", name: "Miner", icon: "construction", maxLevel: 9 },
  { id: "electroDragon", name: "Electro Dragon", icon: "electric_bolt", maxLevel: 5 },
  { id: "yeti", name: "Yeti", icon: "snowman", maxLevel: 4 },
  { id: "dragonRider", name: "Dragon Rider", icon: "paragliding", maxLevel: 3 },
];

// Spells data
export const SPELLS = [
  { id: "lightning", name: "Lightning", icon: "flash_on", maxLevel: 9 },
  { id: "healing", name: "Healing", icon: "healing", maxLevel: 8 },
  { id: "rage", name: "Rage", icon: "speed", maxLevel: 6 },
  { id: "jump", name: "Jump", icon: "height", maxLevel: 4 },
  { id: "freeze", name: "Freeze", icon: "ac_unit", maxLevel: 7 },
  { id: "clone", name: "Clone", icon: "content_copy", maxLevel: 5 },
  { id: "invisibility", name: "Invisibility", icon: "visibility_off", maxLevel: 4 },
  { id: "poison", name: "Poison", icon: "science", maxLevel: 8 },
  { id: "earthquake", name: "Earthquake", icon: "waves", maxLevel: 5 },
  { id: "haste", name: "Haste", icon: "timelapse", maxLevel: 5 },
  { id: "skeleton", name: "Skeleton", icon: "skull", maxLevel: 7 },
  { id: "bat", name: "Bat", icon: "dark_mode", maxLevel: 6 },
];

// Heroes data
export const HEROES = [
  { id: "barbarianKing", name: "Barbarian King", maxLevel: 85 },
  { id: "archerQueen", name: "Archer Queen", maxLevel: 85 },
  { id: "grandWarden", name: "Grand Warden", maxLevel: 60 },
  { id: "royalChampion", name: "Royal Champion", maxLevel: 35 },
];

// Subscription plans
export const SUBSCRIPTION_PLANS = [
  {
    id: 1,
    name: "Free",
    price: 0,
    billingCycle: "month",
    isMostPopular: false,
    features: [
      { name: "Basic strategy recommendations", included: true },
      { name: "5 strategy generations per day", included: true },
      { name: "Access to community strategies", included: true },
      { name: "Video strategy guides", included: false },
      { name: "Advanced battle analysis", included: false },
    ],
  },
  {
    id: 2,
    name: "Pro",
    price: 4.99,
    billingCycle: "month",
    isMostPopular: true,
    features: [
      { name: "All Free features", included: true },
      { name: "Unlimited strategy generations", included: true },
      { name: "Video strategy guides", included: true },
      { name: "Base scanning with AI", included: true },
      { name: "Advanced battle analysis", included: false },
    ],
  },
  {
    id: 3,
    name: "Premium",
    price: 9.99,
    billingCycle: "month",
    isMostPopular: false,
    features: [
      { name: "All Pro features", included: true },
      { name: "Advanced battle analysis", included: true },
      { name: "Custom base layouts", included: true },
      { name: "Priority support", included: true },
      { name: "Early access to new features", included: true },
    ],
  },
];

// FAQ
export const FAQ_ITEMS = [
  {
    question: "What is included in the free trial?",
    answer: "All paid plans include a 7-day free trial with full access to all features of that plan. You can cancel anytime during the trial period and you won't be charged."
  },
  {
    question: "How do I cancel my subscription?",
    answer: "You can cancel your subscription at any time from your account settings. If you cancel during your free trial, you won't be charged."
  },
  {
    question: "Can I change my plan later?",
    answer: "Yes, you can upgrade or downgrade your plan at any time. If you upgrade, you'll be charged the prorated difference. If you downgrade, the new rate will apply at the next billing cycle."
  },
  {
    question: "How accurate are the AI-generated strategies?",
    answer: "Our AI is trained on thousands of successful attacks and is continuously improving. Success rates vary based on execution and base design, but our strategies typically achieve 80%+ success rates when properly executed."
  },
  {
    question: "Do I need to be online to use the strategy generator?",
    answer: "Yes, an internet connection is required to generate new strategies as they are processed by our AI servers. However, you can save strategies for offline viewing."
  }
];

// Latest strategies
export const LATEST_STRATEGIES = [
  {
    id: 1,
    title: "Dragon Rider Attack TH12 vs TH12",
    addedDays: 2,
    description: "Powerful air attack strategy using Dragon Riders with Lightning and Rage spells.",
    successRate: 90,
  },
  {
    id: 2,
    title: "Super Witch Smash TH14",
    addedDays: 5,
    description: "Overwhelming ground attack with Super Witches, Golems and Bat Spells.",
    successRate: 85,
  },
  {
    id: 3,
    title: "Hybrid Miner + Hog TH11",
    addedDays: 7,
    description: "Powerful hybrid attack using Miners and Hog Riders with Queen Walk.",
    successRate: 80,
  },
  {
    id: 4,
    title: "Electro Dragon Rush TH13",
    addedDays: 10,
    description: "Fast and effective 3-star strategy with Electro Dragons and Rage spells.",
    successRate: 82,
  },
  {
    id: 5,
    title: "Queen Charge LaLoon TH11-12",
    addedDays: 14,
    description: "Technical attack strategy featuring Queen charge and Lava Hound + Balloon combo.",
    successRate: 87,
  },
  {
    id: 6,
    title: "GoWiPe for TH10",
    addedDays: 21,
    description: "Classic and reliable Golem, Wizard, and P.E.K.K.A combination for TH10.",
    successRate: 75,
  }
];
