import { pgTable, text, serial, integer, boolean, json, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable("sessions", {
  sid: varchar("sid").primaryKey(),
  sess: json("sess").notNull(),
  expire: timestamp("expire").notNull(),
});

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password"),  // Can be null for OAuth users
  email: text("email").notNull().unique(),
  googleId: text("google_id").unique(), // For Google authentication
  firstName: text("first_name"),
  lastName: text("last_name"),
  profileImageUrl: text("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  subscriptionPlan: text("subscription_plan").default("free"),
  subscriptionEnd: timestamp("subscription_end"),
  trialEnd: timestamp("trial_end"),
});

export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true, 
  createdAt: true,
  subscriptionPlan: true,
  subscriptionEnd: true,
  trialEnd: true
});

// Strategy schema
export const strategies = pgTable("strategies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  userTownHallLevel: integer("user_town_hall_level").notNull(),
  opponentTownHallLevel: integer("opponent_town_hall_level").notNull(),
  troops: json("troops").notNull(),
  spells: json("spells").notNull(),
  heroes: json("heroes").notNull(),
  content: text("content").notNull(),
  videoUrl: text("video_url"),
  successRate: integer("success_rate"),
  createdAt: timestamp("created_at").defaultNow(),
  isPublic: boolean("is_public").default(true),
  userId: integer("user_id").references(() => users.id),
});

export const insertStrategySchema = createInsertSchema(strategies).omit({ 
  id: true, 
  createdAt: true,
  videoUrl: true,
  successRate: true
});

// Subscription plan schema
export const subscriptionPlans = pgTable("subscription_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: integer("price").notNull(),
  billingCycle: text("billing_cycle").notNull(),
  features: json("features").notNull(),
});

export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans).omit({ 
  id: true
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Strategy = typeof strategies.$inferSelect;
export type InsertStrategy = z.infer<typeof insertStrategySchema>;

export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = z.infer<typeof insertSubscriptionPlanSchema>;
